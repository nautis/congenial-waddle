<?php
/**
 * MURA CHILD THEME functions and definitions
 *
 *
 * @package WordPress
 * @subpackage mura
 * @since 1.0
 * @version 1.1
 */

// ========================================================
// Add your own functions and customisations
// ========================================================
function mura_child_scripts() {

	wp_enqueue_style( 'mura-child-style', get_stylesheet_directory_uri() . '/style.css', array(), null );
}
add_action( 'wp_enqueue_scripts', 'mura_child_scripts', 20 );
